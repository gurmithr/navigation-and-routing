import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function ToDoList({ tasks }) {
  return (
    <View>
      {tasks.map((task, index) => (
        <View key={index} style={styles.task}>
          <Text style={styles.taskText}>{task}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  task: {
    padding: 10,
    borderBottomWidth: 2,
    borderColor: '#f0ffff',
    backgroundColor: 'white',
  },
  taskText: {
    fontSize: 20, 
  },
});
